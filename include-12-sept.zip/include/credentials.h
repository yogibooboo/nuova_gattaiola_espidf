#ifndef CREDENTIALS_H
#define CREDENTIALS_H

#define WIFI_SSID "VodafoneRibes"
#define WIFI_PASSWORD "scheggia2000"

#endif // CREDENTIALS_H